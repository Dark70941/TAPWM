module.exports = function(app){
    app.get('/admin/adicionar_professor', function(req,res){
        res.render('admin/adicionar_professor');
    });

    app.post('/professor/salvar', async function(req,res){
        try {
            const professor = req.body;

            // obter pool a partir da função de conexão registrada em app.config
            const connectionFn = app.config.dbConnection;
            const pool = await connectionFn();

            const professoresModel = app.models.professormodel;

            // usar o model para salvar no banco
            professoresModel.salvarProfessor(professor, pool, (error, results)=>{
                if(error){
                    console.error('Erro ao inserir no banco:', error);
                    return res.status(500).send('Erro ao salvar professor');
                }
                console.log('Professor criado com sucesso');
                return res.redirect('/informacao/professores');
            });

        } catch (err) {
            console.error('Erro no handler /professor/salvar:', err);
            res.status(500).send('Erro interno');
        }
    });
}